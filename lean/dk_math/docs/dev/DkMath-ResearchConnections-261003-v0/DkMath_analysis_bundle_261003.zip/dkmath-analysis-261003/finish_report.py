from pathlib import Path
import csv, json, hashlib, zipfile

HERE=Path(__file__).resolve().parent; ROOT=HERE.parent/'dkmath/lean/dk_math'
COMMIT='f16282e5b44bd5fe5afa1a15d29f1598cae575cd'
base=f'https://github.com/Deskuma/dkmath/blob/{COMMIT}/lean/dk_math/'
paths=[
 'DkMath/Lib.lean',
 'DkMath/CFBRC/CyclotomicNorm.lean',
 'DkMath/CFBRC/CyclotomicIdeal.lean',
 'DkMath/NumberTheory/AKSBridge.lean',
 'DkMath/NumberTheory/Gauge/Exponent.lean',
 'DkMath/NumberTheory/BinomialPrimePower.lean',
 'DkMath/NumberTheory/GNThreeHenselDepth.lean',
 'DkMath/NumberTheory/GNThreePairedDepth.lean',
 'DkMath/NumberTheory/PrimorialUniverse/FiniteReservationEscape.lean',
 'DkMath/NumberTheory/CyclotomicQRTraceOneBridge.lean',
 'DkMath/FLT/Prime/PrimeCyclotomicTraceOne.lean',
 'DkMath/FLT/Prime/PrimeCyclotomicIdeal.lean',
 'DkMath/FLT/Three/PositiveCubicNormalization.lean',
 'DkMath/FLT/Five/Main.lean',
 'DkMathTest/FLT/Prime/CurrentCarrierOwnershipProbe.lean',
 'DkMath/FLT/Seven/SevenRamifiedFusionDirectChartObstruction.lean',
 'DkMath/Tromino/IntegralMod2Bridge.lean',
 'DkMath/Tromino/PortF2Exactness.lean',
 'DkMath/Tromino/PortGenusZeroHolonomy.lean',
 'DkMath/NumberTheory/Goldbach/Capacity.lean',
 'DkMath/NumberTheory/Goldbach/Limitations.lean',
 'DkMath/RH.lean',
 'DkMath/RH/CFBRC/StandardZetaBridge.lean',
 'docs/dev/GTail-Cyclotomic-Norm-Bridge-260922-v0/report-006.md',
 'docs/dev/GTail-Cyclotomic-Norm-Bridge-260922-v0/FLT7-REENTRY-HANDOFF-006.md',
]
paths+=sorted(str(p.relative_to(ROOT)) for p in (ROOT/'DkMath/Lib').rglob('*.lean'))
for p in paths: assert (ROOT/p).is_file(),p
decls=list(csv.DictReader((HERE/'declarations.csv').open()))
selected=['gcd_GTail_eq_gcd_choose','traceOne_dvd_iff_norm_dvd_mul_conj_coordinates',
 'traceOne_pow_core_landing_iff','not_mem_primePower_succ_of_conjugate_norm_cutoff',
 'cyclotomicLinearFactor_norm_eq_GN','standardZeta_map_zero_iff_riemannHypothesis',
 'fermatThree_no_positive_solution','flt5Target','currentLinearCarrier_not_mem_currentKernel_pow_succ']
links='| 根拠ファイル | 固定ソース |\n|---|---|\n'
for p in paths: links+=f'| `{p}` | [ソース]({base+p}) |\n'
links+='\n主要な端点の宣言位置：\n\n'
for name in selected:
 matches=[d for d in decls if d['name']==name]
 assert matches,name
 for d in matches:
  rel=d['path'].split('lean/dk_math/',1)[1]
  links+=f'- [`{name}` — {rel}:{d["line"]}]({base+rel}#L{d["line"]})\n'
report=HERE/'DkMath_研究調査報告_261003.md'
text=report.read_text()
if '<!-- SOURCE_LINKS -->' in text:
 text=text.replace('<!-- SOURCE_LINKS -->',links)
 text=text.replace('https://sites.math.rutgers.edu/~weibel/Kbook/Kbook.pdf','[Weibel, The K-book](https://sites.math.rutgers.edu/~weibel/Kbook/Kbook.pdf)')
 report.write_text(text)
assert '<!-- SOURCE_LINKS -->' not in report.read_text()
files=sorted(p for p in HERE.iterdir() if p.is_file() and p.name!='artifact_manifest.json')
manifest={'commit':COMMIT,'files':[{ 'filename':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(HERE/'artifact_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
bundle=HERE.parent/'DkMath_analysis_bundle_261003.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as zf:
 for p in sorted(HERE.iterdir()):
  if p.is_file(): zf.write(p,arcname='dkmath-analysis-261003/'+p.name)
with zipfile.ZipFile(bundle) as zf: assert zf.testzip() is None
print(json.dumps({'report':str(report),'report_bytes':report.stat().st_size,'bundle':str(bundle),'bundle_bytes':bundle.stat().st_size,'source_files_linked':len(paths)},ensure_ascii=False))
