"""Exact arithmetic checks for proposed connections; not Lean formal proofs."""
import json, math, random
from pathlib import Path
import sympy as S

out=Path(__file__).resolve().parent; T,z,y=S.symbols('T z y'); rng=random.Random(261003)
results={}
def gn(n,g,u): return sum(math.comb(n,j+1)*g**j*u**(n-1-j) for j in range(n))
def valuation(q,a):
    assert a != 0
    k=0
    while a%q==0: k+=1;a//=q
    return k

# Determinant of multiplication by z-yT on Z[T]/(T^n-1).
for n in range(1,13):
    shift=S.zeros(n)
    for j in range(n): shift[(j+1)%n,j]=1
    assert S.expand((z*S.eye(n)-y*shift).det(method='domain-ge')-(z**n-y**n))==0
results['cyclic_determinant']={'ranks':list(range(1,13)),'result':'exact symbolic identities passed'}

# Integral augmentation/cyclotomic evaluation lattice has index p.
indices={}
for p in [2,3,5,7,11,13]:
    phi=S.Poly(S.cyclotomic_poly(p,T),T); rows=[]
    columns=[]
    for j in range(p):
        rem=S.rem(S.Poly(T**j,T),phi)
        columns.append([1]+[rem.nth(i) for i in range(p-1)])
    matrix=S.Matrix.hstack(*[S.Matrix(c) for c in columns]);indices[str(p)]=abs(int(matrix.det()))
    assert indices[str(p)]==p
    for _ in range(40):
        bs=[rng.randint(-5,5) for _ in range(p-1)];c=rng.randint(-5,5)
        a=sum(bs)+p*c
        coeff=bs+[0];coeff=[b+c for b in coeff]
        assert matrix*S.Matrix(coeff)==S.Matrix([a]+bs)
        # Residues of pth roots glue because t^p=t in F_p.
        for a0 in range(p):
            for b0 in range(p): assert ((a0**p-b0**p)%p==0)==(a0==b0)
results['integral_fiber_product']={'lattice_indices':indices,'reconstruction_cases':240,'root_residue_gluing':'passed'}

count=0
for m in range(1,8):
 for n in range(1,8):
  for g in range(7):
   for u in range(7):
    assert gn(m*n,g,u)==gn(m,g,u)*gn(n,g*gn(m,g,u),u**m)
    count+=1
results['GN_composition']={'exact_integer_cases':count,'includes_zero_gap':True}

# Adjugate detects lattice divisibility; determinant alone does not.
landing=0
for rank in [2,3,6]:
 for _ in range(50):
    matrix=S.Matrix(rank,rank,[rng.randint(-4,4) for _ in range(rank*rank)])
    det=int(matrix.det())
    if not det: continue
    adj=matrix.adjugate();v=S.Matrix([rng.randint(-20,20) for _ in range(rank)])
    residues=all(int(a)%abs(det)==0 for a in adj*v)
    integral=all(a.q==1 for a in matrix.inv()*v)
    assert residues==integral
    w=S.Matrix([rng.randint(-5,5) for _ in range(rank)])
    assert all(int(a)%abs(det)==0 for a in adj*(matrix*w))
    landing+=1
results['adjugate_lattice_landing']={'nonsingular_matrices_checked':landing,'ranks':[2,3,6]}

# Complete multiplication tables on the same additive group F_2^2.
states=[(a,b) for a in range(2) for b in range(2)]
def mul_s(s,x,w):
    a,b=x;c,d=w;return ((a*c+s*b*d)%2,(a*d+b*c+b*d)%2)
def mul_g(x,w):
    a,b=x;c,d=w;return ((a*c+b*d)%2,(a*d+b*c)%2)
table={}
for name,mul in [('trace_even',lambda x,w:mul_s(0,x,w)),('trace_odd',lambda x,w:mul_s(1,x,w)),('gaussian',mul_g)]:
    units=[x for x in states if any(mul(x,w)==(1,0) for w in states)]
    nil=[x for x in states if x!=(0,0) and mul(x,x)==(0,0)]
    squares=[mul(x,x) for x in states]
    table[name]={'units':len(units),'nonzero_square_zero':len(nil),'squares':squares}
assert [table[k]['units'] for k in table]==[1,3,2]
assert table['gaussian']['nonzero_square_zero']==1
for x in states:
 for w in states:
    a,b=x;c,d=w
    product=mul_s(0,x,w)
    assert (product[0],(product[0]+product[1])%2)==((a*c)%2,((a+b)*(c+d))%2)
results['four_state_rings']=table

lift_cases=[]
for p,q in [(3,7),(3,13),(3,19),(5,11),(5,31),(7,29),(7,43)]:
    roots=[g for g in range(q) if gn(p,g,1)%q==0]
    assert len(roots)==p-1
    for k in range(1,5):
        next_roots=[]
        for r in roots:
            candidates=[r+d*q**k for d in range(q) if gn(p,r+d*q**k,1)%q**(k+1)==0]
            assert len(candidates)==1
            next_roots+=candidates
        roots=next_roots
    lift_cases.append({'p':p,'q':q,'root_count_at_depth5':len(roots),'sample_root':roots[0]})
results['prime_shell_hensel']=lift_cases
for p in [2,3,5,7]:
 for e in [1,2]:
    d=p**e
    assert all(math.comb(d,k)%p==0 for k in range(1,d))
results['hasse_frobenius']={'prime_powers':[2,4,3,9,5,25,7,49],'result':'all interior coefficients vanish mod p'}

# Predictions fail without their hypotheses.
assert gn(3,2,3)==49
tail=sum(math.comb(9,8+k)*3**k for k in range(2))
assert tail==12 and valuation(3,tail)==1 and valuation(3,math.comb(9,8))==2
results['counterexamples']={'unramified_squarefree_shell':{'GN3(2,3)':49,'v7':2},'higher_tail_head_valuation':{'d':9,'r':8,'x':3,'u':1,'GTail':12,'v3_tail':1,'v3_head':2},'norm_divisibility_not_element_divisibility':{'alpha':'2-i','beta':'2+i','norms':[5,5],'alpha_conj_beta':[3,-4],'divisible_by_5':False}}
(out/'verification_results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
