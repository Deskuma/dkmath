# DkMath develop research analysis — 2026-10-03

Pinned source: Deskuma/dkmath develop, commit f16282e5b44bd5fe5afa1a15d29f1598cae575cd.

Start with `DkMath_研究調査報告_261003.md`.

Contents:

- `modules.csv`: all 2,177 tracked Lean files, imports, line counts, SHA-256 hashes, and membership in the DkMath import closure.
- `declarations.csv`: syntactic declaration candidates, module, path, line, kind, and written name. Names are not namespace-resolved.
- `explicit_obligations.csv`: explicit sorry/admit/axiom tokens after removing nested comments and string literals.
- `inventory_summary.json`, `entrypoint_syntax_audit.json`: reproducible summaries. These are not transitive Lean axiom audits.
- `verify_connections.py`, `verification_results.json`: exact arithmetic/symbolic checks for mathematical connections and counterexamples. These are not Lean proofs.
- `scan_workspace.py`: rebuild the index against a sibling checkout named `dkmath`.

Run:

```bash
python3 scan_workspace.py
python3 -m pip install sympy
python3 verify_connections.py
```

The second script requires SymPy. No source repository changes were made. No Lean rebuild completed in this analysis environment: the downloaded v4.34.1 binary stopped at `error: failed to locate application`. The user's GREEN/10334-job build is treated as supplied evidence, not a build independently reproduced here.

The named snapshot was not obtained; its SHA-256 was not checked. The analysis used the pinned Git checkout above.
