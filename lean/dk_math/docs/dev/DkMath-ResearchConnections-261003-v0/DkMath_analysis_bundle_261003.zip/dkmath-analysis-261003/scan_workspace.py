"""Reproducible syntactic inventory, not a Lean elaborator or axiom auditor."""
import csv, hashlib, json, re, subprocess
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / 'dkmath'
OUT = Path(__file__).resolve().parent

def code_only(text):
    # Preserve positions/newlines; support nested Lean block comments and strings.
    out = list(text); i = 0; depth = 0; line = False; string = False
    while i < len(text):
        c = text[i]; pair = text[i:i+2]
        if line:
            if c == '\n': line = False
            else: out[i] = ' '
        elif depth:
            if pair == '/-':
                out[i:i+2] = [' ', ' ']; depth += 1; i += 1
            elif pair == '-/':
                out[i:i+2] = [' ', ' ']; depth -= 1; i += 1
            elif c != '\n': out[i] = ' '
        elif string:
            if c != '\n': out[i] = ' '
            if c == '\\' and i+1 < len(text):
                i += 1
                if text[i] != '\n': out[i] = ' '
            elif c == '"': string = False
        elif pair == '--':
            line = True; out[i:i+2] = [' ', ' ']; i += 1
        elif pair == '/-':
            depth = 1; out[i:i+2] = [' ', ' ']; i += 1
        elif c == '"': string = True; out[i] = ' '
        i += 1
    return ''.join(out)

paths = subprocess.check_output(['git', 'ls-files', '*.lean'], cwd=ROOT, text=True).splitlines()
modules = []; declarations = []; obligations = []; imports_by_module = {}
pat = re.compile(r'\b(theorem|lemma|def|abbrev|structure|class|inductive|axiom|opaque)\s+([^\s\[({:=]+)')
for rel in paths:
    p = ROOT / rel; raw = p.read_text(); code = code_only(raw)
    marker = 'lean/dk_math/'
    mod = rel.split(marker,1)[1][:-5].replace('/', '.') if marker in rel else rel[:-5].replace('/','.')
    imports = re.findall(r'^\s*import\s+([^\n]+)', code, re.M)
    imports = [x for s in imports for x in s.split()]
    imports_by_module[mod] = imports
    ds = list(pat.finditer(code))
    for m in ds:
        declarations.append(dict(module=mod,path=rel,line=code.count('\n',0,m.start())+1,kind=m[1],name=m[2]))
    for m in re.finditer(r'\b(sorry|admit|axiom)\b',code):
        obligations.append(dict(module=mod,path=rel,line=code.count('\n',0,m.start())+1,token=m[1]))
    modules.append(dict(module=mod,path=rel,lines=len(raw.splitlines()),declaration_candidates=len(ds),imports=';'.join(imports),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))

def closure(start):
    seen=set(); todo=[start]
    while todo:
        m=todo.pop()
        if m in seen or m not in imports_by_module: continue
        seen.add(m); todo.extend(imports_by_module[m])
    return seen

default = closure('DkMath')
for row in modules: row['in_DkMath_import_closure'] = row['module'] in default
for name,rows in [('modules',modules),('declarations',declarations),('explicit_obligations',obligations)]:
    with (OUT/(name+'.csv')).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
groups=Counter(m['module'].split('.')[1] if m['module'].startswith('DkMath.') else m['module'].split('.')[0] for m in modules)
lib=[m for m in modules if m['module'].startswith('DkMath.Lib.')]
summary=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),lean_files=len(modules),lines=sum(x['lines'] for x in modules),declaration_candidates=len(declarations),explicit_tokens=dict(Counter(x['token'] for x in obligations)),lib_files=len(lib),lib_declaration_candidates=sum(m['declaration_candidates'] for m in lib),default_import_closure_files=len(default),families=dict(groups.most_common()),lib_outside_aggregate=sorted(m['module'] for m in lib if m['module'] not in closure('DkMath.Lib')),notes=['Syntactic inventory: names are as written, not fully qualified by namespace.','Generated names, instances without names, and tactic-created declarations are not indexed.','Explicit tokens are not transitive axiom dependencies; use Lean #print axioms for that.','No toolchain rebuild was completed during this analysis.'])
(OUT/'inventory_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
entrypoints=['DkMath','DkMath.Lib','DkMath.FLT.Three','DkMath.FLT.Three.PositiveCubicNormalization','DkMath.FLT.Five.Main','DkMathTest.FLT.Prime.CurrentCarrierOwnershipProbe']
audit={}
for ep in entrypoints:
    reach=closure(ep)
    hits=[o for o in obligations if o['module'] in reach]
    audit[ep]={'project_import_closure_files':len(reach),'explicit_tokens':dict(Counter(o['token'] for o in hits)),'locations':hits}
(OUT/'entrypoint_syntax_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
