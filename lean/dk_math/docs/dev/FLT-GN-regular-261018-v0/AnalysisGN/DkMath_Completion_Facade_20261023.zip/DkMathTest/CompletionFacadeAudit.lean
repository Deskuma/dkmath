/-
Copyright (c) 2026 D. and Wise Wolf. All rights reserved.
Released under MIT license as described in the file LICENSE.
Authors: D. and Wise Wolf.
-/

import DkMath.Completion

/-! Source snapshot symbol smoke-check. This is not an independent proof. -/

#check DkMath.CosmicFormula.add_pow_eq_mul_GTail_one_add_gap
#check DkMath.Lib.Cosmic.powerCore_split
#check DkMath.CosmicFormula.coeffGCD_prime_interior
#check DkMath.CosmicFormula.gcd_GN_eq_gcd_of_one_le
#check DkMath.Gnomon.squareGnomonBand_eq_mul_GTail_two_one
#check DkMath.NumberTheory.Primitive.squareBody_add_one_eq
#check DkMath.NumberTheory.PrimorialUniverse.squareBody_thirty_add_one_eq_thirtyOne_sq
#check DkMath.NumberTheory.Legendre.primeWorldResidues_eq_packetBase
