/-
Copyright (c) 2026 D. and Wise Wolf. All rights reserved.
Released under MIT license as described in the file LICENSE.
Authors: D. and Wise Wolf.
-/

import DkMath.Lib.Cosmic.GTail
import DkMath.Lib.Cosmic.CoreNested
import DkMath.Lib.Cosmic.CoreNestedTransport
import DkMath.Lib.Cosmic.GTailSelection
import DkMath.Lib.Cosmic.GTailFactor
import DkMath.Lib.Cosmic.GTailTransport
import DkMath.Lib.Cosmic.GTailBoundary
import DkMath.Lib.Cosmic.GTailCongruence
import DkMath.Lib.Cosmic.GTailPadic
import DkMath.Lib.Cosmic.GNProductDegree
import DkMath.Lib.Cosmic.GTailCyclotomic

/-!
# Completion research facade

Small, dependency-light facade for general Cosmic completion kernels.

This module introduces NO new mathematical assertion. It only re-exports
existing declarations by imports. No def/theorem/axiom/sorry is added.

Source baseline: snapshot 2026-10-22 00:15.
The facade has been statically checked for import-path existence, but has
not been built with Lean in this audit environment.
-/
